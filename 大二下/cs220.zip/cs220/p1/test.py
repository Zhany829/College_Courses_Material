doc = "<a href="quiz.html"><b>this</b>is<i>quiz11</i></a>"
link = doc.find("a")
link.attrs
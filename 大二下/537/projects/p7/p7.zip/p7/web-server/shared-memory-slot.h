#ifndef __REQUEST_H__

typedef struct
{
    long threadNum;
    int requestCompleted;
    int staticNum;
    int dynamicNum;
} slot_t;

#endif
